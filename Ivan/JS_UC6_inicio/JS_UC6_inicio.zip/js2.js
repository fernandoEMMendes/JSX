let num1 = 2
let num2 = 4
let num3 = 6

let soma1 = num1 + num2 + num3
console.log(soma1)


let decimal1 = 2.5
let decimal2 = 1.3

let soma2 = decimal1 + decimal2
console.log(soma2)


let texto1 = "Olá "
let texto2 = "mundo"

let mensagem = texto1 + texto2
console.log(mensagem)



let texto3 = "Olá "
let texto4 = "mundo "
let numero = 2

let mensagem2 = texto3 + texto4 + numero
console.log(mensagem2)