let subtracao = 8 - 3
console.log(subtracao)


let decimal1 = 5.7
let decimal2 = 2.3

let subtracao2 = decimal1 - decimal2
console.log(subtracao2)


let num1 = 10
let num2 = 3

let resultado = num1 - num2
console.log(resultado)


let divisao = 10 / 2
console.log(divisao)


let decimal3 = 5.5
let decimal4 = 2

let divisao2 = decimal3 / decimal4
console.log(divisao2)