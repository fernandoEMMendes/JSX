let resultado = (2 + 3) * 4
console.log(resultado)


let resultado2 = 10 + 5 - 2
console.log(resultado2)


let resultado3 = (10 + 5) * 2 - 3
console.log(resultado3)


let num1 = 3
let num2 = 4

let resultado4 = num1 * (num1 * num2)
console.log(resultado4)


const Pi = 3.14
let raio = 5
let area = Pi * raio * raio
console.log(area)