let resultado = 10 / 0
console.log(resultado)


let multiplicacao = 5 * 3
console.log(multiplicacao)


let decimal1 = 2.5
let decimal2 = 1.5

let multiplicacao2 = decimal1 * decimal2
console.log(multiplicacao2)


let resultado2 = 10 * 0
console.log(resultado2)


let resultado3 = 2 + 3 * 4
console.log(resultado3)