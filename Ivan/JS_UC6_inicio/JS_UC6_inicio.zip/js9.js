let g = 10
let h = "10"
console.log(g === h)


var x = 5
x = 10
console.log(x)


let y = 5
y = 10
console.log(y)


var a = 5
var b = 10
console.log(a + b)


console.log(c)
console.log(d)