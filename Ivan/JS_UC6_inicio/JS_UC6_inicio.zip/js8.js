var x = 5
console.log(x)


let y = 10


var a = 5
var b = "5"
console.log(a == b)


let c = 10
let d = "10"
console.log(c == d)


let e = 5
let f = "5"
console.log(e === f)