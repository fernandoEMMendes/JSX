let texto = "Olá, mundo!"
let novoTexto = texto.replace("mundo", "JavaScript")
console.log(novoTexto)


let texto2 = "Olá, mundo!"
console.log(texto2.includes("mundo"))
console.log(texto2.includes("JavaScript"))


let texto3 = "JavaScript é uma linguagem poderosa"
let palavras = texto3.split(" ")
console.log(palavras)


let texto4 = "Olá, mundo!"
let novoTexto2 = texto4.trim()
console.log(novoTexto2)


let texto5 = "Olá, mundo!"
console.log(texto.startsWith("Olá"))
console.log(texto5.endsWith("mundo!"))