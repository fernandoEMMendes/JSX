function calcularAreaRetangulo() {
    let base = 5
    let altura = 3
    let area = base * altura
    console.log("A área do retângulo é:", area)
}
calcularAreaRetangulo()


var nota1 = 7
var nota2 = 8
var nota3 = 6

function calcularMedia() {
    var media = (nota1 + nota2 + nota3) / 3
    console.log("A média das notas é:", media)
}
calcularMedia