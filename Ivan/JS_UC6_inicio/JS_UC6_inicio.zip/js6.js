let valor = 10

valor += 5
console.log(valor)


let texto = "Olá, mundo!"
console.log(texto.length)


let texto2 = "JavaScript"
console.log(texto2[0])
console.log(texto2[4])


let saudacao = "Olá "
let nome = "Maria"

let mensagem = saudacao + nome + "!"
console.log(mensagem)


let texto3 = "JavaScript"
console.log(texto3.toUpperCase())
console.log(texto3.toLowerCase())


let texto4 = "Olá, mundo!"
let parte = texto4.slice(5, 8)

console.log(parte)