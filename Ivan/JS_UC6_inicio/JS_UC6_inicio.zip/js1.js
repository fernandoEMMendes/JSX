let soma = 3 + 5
console.log(soma)

let soma2 = 5 + "3"
console.log(soma2)

let mult = 5 * "3"
console.log(mult)