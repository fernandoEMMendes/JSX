let a = 2
let b = 3

let x = (a - b) * -1
console.log(x)

// ax + b = 0